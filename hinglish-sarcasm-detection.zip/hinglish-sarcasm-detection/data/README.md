# Datasets

This project uses two publicly available datasets from Kaggle. Due to size and licensing constraints, they are **not included** in this repository. Please download them manually.

---

## Required Files

Place both CSV files in this `data/` directory:

| Filename | Description |
|---|---|
| `sarcasm_hinghlish_dataset.csv` | ~9,500 Hinglish tweets labeled sarcastic / non-sarcastic |
| `emotion_hinghlish_dataset.csv` | Hinglish text with emotion labels (used to build the emotion lexicon) |

---

## Download Links

- **Hinglish Sarcasm Dataset**: Search on [Kaggle](https://www.kaggle.com) for *"Hinglish sarcasm tweets"*
- **Hinglish Emotion Dataset**: Search on [Kaggle](https://www.kaggle.com) for *"Hinglish emotion dataset"*

---

## Expected Column Format

### Sarcasm Dataset
| Column | Description |
|---|---|
| `text` / `tweet` / `sentence` | The raw Hinglish text |
| `label` / `class` / `target` | Binary: `1` = sarcastic, `0` = not sarcastic |

### Emotion Dataset
| Column | Description |
|---|---|
| `text` / `tweet` / `sentence` | The raw Hinglish text |
| `emotion` / `label` | Emotion label, e.g. `happy`, `sad`, `angry`, `fear` |

The code auto-detects column names matching these keywords.

---

## Data Split

The model uses an 80/20 train/test split (with `random_state=42`). The paper reports a 70/15/15 train/val/test split for the full pipeline.
