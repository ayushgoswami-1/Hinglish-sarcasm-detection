# 🌐 Hinglish Sarcasm Detection — Hybrid Deep Learning Approach

> A multi-feature hybrid system for sarcasm detection in code-mixed Hindi-English (Hinglish) social media text, combining XLM-RoBERTa, BiLSTM, TF-IDF, and emotion encoding with weighted ensemble voting.

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue)](https://python.org)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0%2B-red)](https://pytorch.org)
[![Transformers](https://img.shields.io/badge/HuggingFace-Transformers-yellow)](https://huggingface.co)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 📄 Paper

**"BERT Based Sarcasm Detection Hybrid Approach For Hinglish Languages Using GloVe Embedding"**  
Ayush, Ritika Choudhary, Kishan Kumar — Galgotias University, Greater Noida, India

---

## 🏆 Results

| Model | Accuracy |
|---|---|
| Logistic Regression (TF-IDF) | 90.4% |
| Linear SVM (TF-IDF) | 91.6% |
| XLM-R + BiLSTM + Attention | 94.0% |
| **Weighted Ensemble (Proposed)** | **~95.5%** |

- **F1-Score**: ~0.95–0.96 (macro & weighted)
- **ROC AUC**: >0.97
- **Precision-Recall AP**: 0.99

---

## 🏗️ Architecture

The system uses three parallel feature extraction channels fused into a weighted ensemble:

```
Input Text (Hinglish)
        │
   ┌────▼────┐
   │Language │
   │Detection│
   └────┬────┘
        │
   ┌────▼─────────────────────────────────────┐
   │           Feature Extraction              │
   │  ┌──────────────┐  ┌──────┐  ┌────────┐  │
   │  │XLM-R+BiLSTM  │  │TF-IDF│  │Emotion │  │
   │  │+Attention    │  │n-gram│  │Encoding│  │
   │  └──────┬───────┘  └──┬───┘  └───┬────┘  │
   └─────────┼─────────────┼──────────┼────────┘
             │             │          │
        ┌────▼─────────────▼──────────▼────┐
        │     Feature Fusion (Concatenate) │
        └──────────────────┬───────────────┘
                           │
        ┌──────────────────▼───────────────┐
        │     Ensemble Classifier          │
        │  SVM + LogReg + XLM-R Hybrid     │
        │  (Validation-Weighted Voting)    │
        └──────────────────┬───────────────┘
                           │
               ┌───────────▼──────────┐
               │  Sarcastic / Not     │
               │  Sarcastic + Score   │
               └──────────────────────┘
```

---

## 📁 Repository Structure

```
hinglish-sarcasm-detection/
├── src/
│   ├── model_colab.py        # Full pipeline (Colab-compatible)
│   └── predict.py            # Standalone prediction script
├── notebooks/
│   └── sarcasm_detection.ipynb   # Interactive Colab notebook
├── data/
│   └── README.md             # Dataset download instructions
├── results/
│   └── README.md             # Sample outputs and metrics
├── docs/
│   └── paper_summary.md      # Summary of the research paper
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 🚀 Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/hinglish-sarcasm-detection.git
cd hinglish-sarcasm-detection
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Prepare datasets

Download the datasets from Kaggle and place them in the `data/` folder:
- `sarcasm_hinghlish_dataset.csv`
- `emotion_hinghlish_dataset.csv`

See [`data/README.md`](data/README.md) for links and column format.

### 4. Run in Google Colab (recommended)

Open the notebook directly:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/<your-username>/hinglish-sarcasm-detection/blob/main/notebooks/sarcasm_detection.ipynb)

### 5. Run locally
```bash
python src/predict.py --text "Wow great job failing again"
```

---

## 🧠 Model Details

### Transformer Backbone
- **XLM-RoBERTa Base** (`xlm-roberta-base`) — multilingual encoder pretrained on 100 languages
- Early layers (0–1) are frozen during fine-tuning for efficiency

### Neural Architecture
```
XLM-R Embeddings (768-dim)
    → BiLSTM (256 hidden, bidirectional → 512-dim)
    → Multi-Head Attention (4 heads, 512-dim)
    → Mean Pooling
    → Concat with Emotion Feature (32-dim)
    → Sigmoid Output
```

### TF-IDF Features
- Word n-grams (1–2), max 5,000 features
- Character n-grams (3–5), max 3,000 features

### Emotion Encoding
- Lexicon built from a Hinglish emotion dataset
- Assigns sentiment polarity score (+1 / -1) per word
- Aggregated as a scalar feature per sample

### Ensemble Weighting
Final prediction = weighted average of SVM, Logistic Regression, and Neural Model predictions, weighted by their respective validation accuracy scores.

---

## 📊 Training Details

| Parameter | Value |
|---|---|
| Optimizer | Adam |
| Learning Rate | 2e-5 |
| Batch Size | 8 |
| Epochs | 5 |
| Max Sequence Length | 128 |
| LR Schedule | Linear warmup |
| Loss | Binary Cross-Entropy |

---

## 📦 Dependencies

See [`requirements.txt`](requirements.txt). Key packages:

- `torch >= 2.0`
- `transformers >= 4.30`
- `scikit-learn >= 1.2`
- `langdetect`
- `pandas`, `numpy`, `matplotlib`

---

## 📝 Citation

If you use this work, please cite:

```bibtex
@article{ayush2024hinglish,
  title={BERT Based Sarcasm Detection Hybrid Approach For Hinglish Languages Using GloVe Embedding},
  author={Ayush and Choudhary, Ritika and Kumar, Kishan},
  institution={Galgotias University},
  year={2024}
}
```

---

## 📜 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
